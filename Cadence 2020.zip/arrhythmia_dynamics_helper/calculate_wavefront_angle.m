function angle_in_degrees = calculate_wavefront_angle(u,v)
angle_in_degrees = [];

if ~isempty(u) && ~isempty(v)
    figure;
    u_len = size(u,1);
    v_len = size(v,1);
    norm_u = u;
    norm_v = v;
    if u_len <= v_len
        com_len = u_len;
        norm_v = v(1:com_len,:);
    else
        com_len = v_len;
        norm_u = u(1:com_len,:);
    end
        
    plot(u(:,1), u(:,2), v(:,1), v(:,2)); hold on;
    plot(norm_u(:,1), norm_u(:,2), norm_v(:,1), norm_v(:,2));
    
    CosTheta = max(min(dot(norm_u,norm_v)/(norm(norm_u)*norm(norm_v)),1),-1);
    angle_in_degrees = real(acosd(CosTheta));
end
