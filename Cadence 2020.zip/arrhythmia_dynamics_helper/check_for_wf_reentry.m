function reentry = check_for_wf_reentry(wf, wavefronts, df)
reentry = 0;
cycle_length = round(1000/df);

%use cycle length as a proxy
if wf.lifespan(1,2) <  0.8*cycle_length
    return;
end

%use a point along the wavefront (e.g., mid point)for comparison
% mid_point = [round(wf.location(round(wf.length(1,1)/2),1)),round(wf.location(round(wf.length(1,1)/2),2))];
% num_frames = size(wf.path,1);
% start_frame = round(0.8*cycle_length);
% for i=start_frame:num_frames
%     wf_to_compare = round(wavefronts{1, wf.path(i,1)}{wf.path(i,2),1}.location);
%     if ismember(mid_point(1,1), wf_to_compare(:,1)) && ismember(mid_point(1,2), wf_to_compare(:,2))
%         reentry = 1;
%     end
% end



