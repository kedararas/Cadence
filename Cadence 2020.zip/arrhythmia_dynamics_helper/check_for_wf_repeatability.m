function repeat_wf = check_for_wf_repeatability(wf_dynamics, wf, wavefronts)
repeat_wf = 0;
df = wf_dynamics.df;
cycle_length = round(1000/df);
wf_list = wf_dynamics.wf_multiplicity;
if isempty(wf_list) || (wf.birthday(1,1) - wf_list(1,1)) < 0.8*cycle_length || wf.lifespan(1,2) < 10
    return;
end

path_length = size(wf.path,1);
first_list = cell(path_length,1);
for i=1:path_length
    first_list{i,1} = wavefronts{1,wf.path(i),1}{wf.path(i,2),1}.location;
end

num_wf = size(wf_list,1);
for j=1:num_wf
    %check if the wf size and lifespan is in the ball park, at least 0.8
    length = abs((median(wf.length)) - wf_list(j,3));
    %avg_length = mean(mean(wf.length), wf_list(j,3));
    if length > 0.2* wf_list(j,3) 
        continue;
    end
    
%     if avg_length < 40
%         continue
%     end
%     
    time = abs(wf.lifespan(1,2) - wf_list(j,4));
    if time > 0.2* wf_list(j,4)
        continue;
    end
  
    wf_to_compare = wavefronts{1,wf_list(j,1)}{wf_list(j,2),1};
    wf_path_length = size(wf_to_compare.path,1);
    second_list = cell(wf_path_length,1);
    for k=1:wf_path_length
        second_list{k,1} = wavefronts{1,wf_to_compare.path(k,1)}{wf_to_compare.path(k,2),1}.location;
    end
    frech_dist = get_frechet_distance_single(first_list, second_list);
    
%     debug_temporal_wavefront(first_list, second_list);
%     close all;
    
    [dtw_dist, euclidean_dist] = get_dtw_distance_single(first_list, second_list);
    if median(frech_dist) <= 35 && median(euclidean_dist) <= 20 
        repeat_wf = j;
%         debug_temporal_wavefront(first_list, second_list);
%         disp(median(euclidean_dist));
%         disp(median(frech_dist));
%          close all;
        break;
    end
end



