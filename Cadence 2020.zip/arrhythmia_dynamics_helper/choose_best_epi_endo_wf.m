function wf_cand = choose_best_epi_endo_wf(dissociation_data)

%smallest wf time incidence difference
[~, time_index] = sortrows(abs(dissociation_data(:,1) - dissociation_data(:,5)));

%smallest wf length difference
[~, length_index] = sortrows(abs(dissociation_data(:,3) - dissociation_data(:,7)));

%smallest wf duration difference
[~, duration_index] = sortrows(abs(dissociation_data(:,4) - dissociation_data(:,8)));

%smallest frechet distance
[~, frech_index] = sortrows(dissociation_data(:,9));

%smallest euclidean distance
[~, dist_index] = sortrows(dissociation_data(:,10));

%consolidate rankings
num_wf = size(dissociation_data,1);
index_score = nan(num_wf,1);
for i=1:num_wf
    index_score(i,1) = find(time_index == i) + find(length_index == i)...
        + find(duration_index == i) + find(frech_index == i)...
        + find(dist_index == i);
end

[sorted_index_score, sorted_index] = sortrows(index_score);
wf_cand = dissociation_data(sorted_index(1,1),:);

end

