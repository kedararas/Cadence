function [ps_status, ps_cand] = choose_ps_cand(ps, current_ps_list, next_ps_list)

first_list = [];
if ~isempty(current_ps_list)
    num_first_ps = size(current_ps_list,1);
    for i=1:num_first_ps
        ps_object = current_ps_list{i,1};
        first_list(i,:) = ps_object.location;
    end
end

second_list = [];
if ~isempty(next_ps_list)
    num_second_ps = size(next_ps_list,1);
    for i=1:num_second_ps
        ps_object = next_ps_list{i,1};
        second_list(i,:) = ps_object.location;
    end 
end

if isempty(first_list) || isempty(second_list)
    ps_status = 'EXPIRED';
    disp(ps_status);
    ps_cand = [];
    return
end

relative_distance = pdist2(first_list, second_list);
[sorted_dist, sorted_index] = sortrows(relative_distance(ps.index,:)');
if sorted_dist(1,1) < 3
    ps_cand = next_ps_list{sorted_index(1,1),1};
    ps_status = 'ALIVE';
    %disp(ps_status);
    return
else
     ps_status = 'EXPIRED';
    disp(ps_status);
    ps_cand = [];
    return
end



