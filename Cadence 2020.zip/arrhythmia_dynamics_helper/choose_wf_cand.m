function [wf_status, wf_cand, wf_mate, wf_child] = choose_wf_cand(wf, current_wf_list, next_wf_list, next_wf_black_list, debug_mode)

%first, find similar wavefronts and neighbors for the wavefront in focus in
%the next frame
wf_future_neighbors = get_wf_neighbors(wf, next_wf_list, 10, debug_mode); %euclidean
[wf_similars, frech_dist] = get_similar_wf(wf.index, current_wf_list, next_wf_list, next_wf_black_list, 40); %frechet

% if debug_mode
%      close all;
%      debug_wavefront(current_wf_list, next_wf_list, wf, wf_similars);
% end

%second, find similar wavefronts and neighbors for the closest neighbor, if any, of
%wavefront in focus in the next frame
if ~isempty(wf.neighbors) && ~isempty(wf.neighbors{end,1}) && wf.neighbors{end,1}(1,3) == wf.frame
    closest_wf = current_wf_list{wf.neighbors{end,1}(1,2),1};
    closest_wf_future_neighbors = get_wf_neighbors(closest_wf, next_wf_list, 10, debug_mode); %euclidean
    [closest_wf_similars, closest_frech_dist] = get_similar_wf(closest_wf.index, current_wf_list, next_wf_list, next_wf_black_list, 40); %frechet
else
    closest_wf = [];
    closest_wf_future_neighbors = [];
    closest_wf_similars = [];
end

if ~isempty(wf.neighbors) && ~isempty(wf.neighbors{end,1}) &&...
        wf.neighbors{end,1}(1,3) == wf.frame && size(wf.neighbors{end,1},1) > 1
    second_closest_wf = current_wf_list{wf.neighbors{end,1}(2,2),1};
    second_closest_wf_future_neighbors = get_wf_neighbors(second_closest_wf, next_wf_list, 10, debug_mode); %euclidean
    [second_closest_wf_similars, second_closest_frech_dist] = get_similar_wf(second_closest_wf.index, current_wf_list, next_wf_list, next_wf_black_list, 40); %frechet
else
    second_closest_wf = [];
    second_closest_wf_future_neighbors = [];
    second_closest_wf_similars = [];
end

%scenario 1: wf and its closest neighbor merged to form one wavefront
% this would be, if the wf and closest neighbor are tied to the same future
% wf by minimal euclidean distance
%neighbor exists
merged = 0;
if ~isempty(wf.neighbors) && ~isempty(closest_wf_future_neighbors) && ~isempty(wf_future_neighbors)
    if closest_wf_future_neighbors(1,2) == wf_future_neighbors(1,2)...
            && closest_wf_future_neighbors(1,1) < 1 && wf_future_neighbors(1,1) < 1
        num_wf_neigh = size(find(wf_future_neighbors(:,1) < 1),1);
        num_closest_wf_neigh = size(find(closest_wf_future_neighbors(:,1) < 1),1);
        if num_wf_neigh == 1 && num_closest_wf_neigh == 1
            merged = 1;
        elseif num_wf_neigh >1 || num_closest_wf_neigh > 1
            if abs((wf.length(end,1)+closest_wf.length(end,1)) - wf_future_neighbors(1,3)) < 0.2*wf_future_neighbors(1,3)
                merged = 1;
            end
        end
        if (~isempty(closest_wf_similars) && ~isempty(wf_similars)...
                && closest_wf_similars(1,2) ~= wf_similars(1,2))
            merged = 0;
        end
    end
end

if ~merged
    if ~isempty(wf.neighbors) && ~isempty(second_closest_wf_future_neighbors) && ~isempty(wf_future_neighbors)
        if second_closest_wf_future_neighbors(1,2) == wf_future_neighbors(1,2)...
                && second_closest_wf_future_neighbors(1,1) < 1 && wf_future_neighbors(1,1) < 1
            num_wf_neigh = size(find(wf_future_neighbors(:,1) < 1),1);
            num_second_closest_wf_neigh = size(find(second_closest_wf_future_neighbors(:,1) < 1),1);
            if num_wf_neigh == 1 && num_second_closest_wf_neigh == 1
                merged = 1;
            elseif num_wf_neigh >1 || num_second_closest_wf_neigh > 1
                if abs((wf.length(end,1)+second_closest_wf.length(end,1)) - wf_future_neighbors(1,3)) < 0.2*wf_future_neighbors(1,3)
                    merged = 1;
                end
            end
            if (~isempty(second_closest_wf_similars) && ~isempty(wf_similars)...
                    && second_closest_wf_similars(1,2) ~= wf_similars(1,2))
                merged = 0;
            end
        end
    end
end

if merged
    %pointing to the same future wf
    wf_status = 'MERGED';
    disp(wf_status);
    wf_child = next_wf_list{wf_future_neighbors(1,2),1};
    wf_mate = closest_wf;
    wf_cand = [];
    return;
end

%scenario 2: wavefront has fragmented in to child wavefronts (2)
%if ~isempty(wf_similars) && ~isempty(wf_future_neighbors)
fragmented = 0;
if ~isempty(wf_future_neighbors)
    num_euclidean_fragments = find(wf_future_neighbors(:,1) < 1, 2);
else
    num_euclidean_fragments = [];
end

if ~isempty(closest_wf_future_neighbors)
    closest_num_euclidean_fragments = find(closest_wf_future_neighbors(:,1) < 1, 2);
else
    closest_num_euclidean_fragments = [];
end

if ~isempty(num_euclidean_fragments) && size(num_euclidean_fragments,1) == 2
    if (~isempty(wf_similars) && wf_similars(1,1) < 10) ||...
            (~isempty(closest_wf_similars) && closest_wf_similars(1,1) < 10) %not pointing to itself
        fragmented = 0;
    else
        wf_length = wf.length(end,1);
        wf_n1 = next_wf_list{wf_future_neighbors(1,2),1}.length(1,1);
        wf_n2 = next_wf_list{wf_future_neighbors(2,2),1}.length(1,1);
        frag_length = wf_n1 + wf_n2;
        if frag_length <= wf_length
            fragmented = 1;
        else
            if wf_length > wf_n1 && wf_length > wf_n2
                fragmented = 1;
            end
        end
    end
end

if fragmented
    wf_status = 'FRAGMENTED';
    disp(wf_status);
    wf_child{1,1} = next_wf_list{wf_future_neighbors(1,2),1};
    wf_child{2,1} = next_wf_list{wf_future_neighbors(2,2),1};
    wf_mate = [];
    wf_cand = [];
    return;
end




%scenario 3: wavefront has maintained its unique identity
if (~isempty(wf_similars) && wf_similars(1,1) < 10)||... %good match
        (~isempty(wf_similars) && ~isempty(wf_future_neighbors) &&...
        wf_similars(1,2) == wf_future_neighbors(1,2) && wf_future_neighbors(1,1) < 1) ||... %fair match
        (~isempty(wf_future_neighbors) && wf_future_neighbors(1,1) < 1) &&...
        abs(wf.length(end,1) - wf_future_neighbors(1,3)) < 0.2*wf.length(end,1)
    
    if ~isempty(wf_similars)
        wf_cand = next_wf_list{wf_similars(1,2),1};
        if size(wf_cand.length,1) == 1 && isempty(wf_cand.cause_of_death) &&...
                abs(wf.length(end,1) - wf_similars(1,3)) < 0.2*wf.length(end,1)
            wf_status = 'ALIVE';
            disp(wf_status);
            wf_mate = [];
            wf_child = [];
            return;
        end
    end
    
    for i=1:size(wf_future_neighbors,1)
        wf_cand = next_wf_list{wf_future_neighbors(i,2),1};
        if size(wf_cand.length,1) > 1
            %disp('problem finding the correct wf, selecting the next nearest neighbor, if available');
            continue
        else
            wf_status = 'ALIVE';
            disp(wf_status);
            wf_mate = [];
            wf_child = [];
            return;
        end
    end
end

wf_status = 'EXPIRED';
disp(wf_status);
wf_cand = [];
wf_mate = [];
wf_child = [];
return;













