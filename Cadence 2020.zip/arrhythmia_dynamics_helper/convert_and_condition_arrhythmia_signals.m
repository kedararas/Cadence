function convert_and_condition_arrhythmia_signals(dir_path, directory, num_cameras, debug_mode)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DESCRIPTION
% convert_and_condition_arrhythmia_signals is a wrapper function for extracting data from
% SciMedia's proprietary file format and saving it as a *.mat file for
% future use. It invokes the CMOSconverter function as well as basic signal
% conditioning functions such as background noise removal, drift
% correction, spatial binning, and temporal filtering.
%
% INPUT
% directory = directory name associated with the experiment
% debug_mode = display messages during the execution of function
%
% AUTHOR
% Kedar Aras
%
% DATE CREATED
% 02/25/2020
%
% REVISED
% 02/25/2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gsd_data_path = '/data_optical/gsd/arrhythmia/';
mat_data_path= '/data_optical/mat/arrhythmia/';
absolute_gsd_path = strcat(dir_path,'/', directory, gsd_data_path);
absolute_mat_path = strcat(dir_path,'/', directory, mat_data_path);
old_path = cd(absolute_gsd_path);
file_list = dir('*.gsh');
cd(old_path);
[files_r, ~] = size(file_list);

epi_mask_file_name = strcat(dir_path,'/', directory, '/data_optical/mat/masks/Epicardium-mask.mat');
epi_mask_file = load(epi_mask_file_name);
epi_mask = epi_mask_file.mask{1,2};

endo_mask_file_name = strcat(dir_path,'/', directory, '/data_optical/mat/masks/Endocardium-mask.mat');
endo_mask_file = load(endo_mask_file_name);
endo_mask = endo_mask_file.mask{1,2};


%iterate through each .gsh or .mat data file
for i = 7:num_cameras:files_r
    epi_data = [];
    endo_data = [];
    for j=1:num_cameras
%         try
            %Step 1: Load the .gsh file (if .mat file does not exist) and convert it to .mat file
            cmos_all_data = [];
            mat_file_name = strcat(absolute_mat_path, file_list(i+j-1).name);
            mat_file_name = strrep(mat_file_name, '.gsh', '.mat');
            
            if debug_mode
                message = strcat('1)Beginning processing of data file...', mat_file_name);
                disp(message);
            end
            
            %Step 2: Basic filtering of raw cmos data (if not filtered)
            %it seems the matrix needed to be rotated flipped to match the
            %image background
            fclose('all');
            cmos_con_data = CMOSconverter(absolute_gsd_path, file_list(i+j-1).name);
            cmos_data = fliplr(rot90(cmos_con_data.raw_cmos_data,3));
           
            
            if debug_mode
                message = strcat('2)CMOS Data structure loaded');
                disp(message);
            end
            
            %Step 3: Spatial filtering (5x5 binning)
            bin_cmos_data = binning(cmos_data, 5); % 5x5 spatial filter
            
            if debug_mode
                message = strcat('3)CMOS Data spatially filtered using 5x5 binning function');
                disp(message);
            end
            
            %Step 4: Temporal filtering (FIR [0,50])
            
            %filt_bin_cmos_data = filter_data(bin_cmos_data,1000,100,0,100);
            over_filt_bin_cmos_data = filter_data(bin_cmos_data,1000,100,0,100);
            
            if debug_mode
                message = strcat('4)CMOS Data temporally filtered using FIR filter with [0,100] band pass frequency');
                disp(message);
            end
            
            %Step 5: Drift Correction
            %drift_filt_bin_cmos_data = remove_Drift(filt_bin_cmos_data,[]);
            drift_over_filt_bin_cmos_data = remove_Drift(over_filt_bin_cmos_data);
            if debug_mode
                message = strcat('5)CMOS Data drift corrected using detrend function');
                disp(message);
            end
            
            %Step 6: Data Masking
            [num_rows, num_cols] = size(epi_mask);
             if j==1 %epi_mask
                 mask = ones(num_rows,num_cols);
                 mask = mask .* epi_mask;
                 mask(mask == 0) = nan;
                 cmos_all_data.mask = mask;
             else
                 mask = ones(num_rows,num_cols);
                 mask = mask .* endo_mask;
                 mask(mask == 0) = nan;
                 cmos_all_data.mask = mask;
             end
            
            cmos_all_data.frequency = cmos_con_data.frequency;
            cmos_all_data.acqFreq = cmos_con_data.acqFreq;
            cmos_all_data.filt_data = drift_over_filt_bin_cmos_data;
            cmos_all_data.bgimage = cmos_con_data.bgimage;
            cmos_all_data.file_name = mat_file_name;
            
            
%             msg = strcat('Sampling Frequency is: ', num2str(cmos_con_data.frequency));
%             disp(msg);
            
            %Step 7: Dominant Frequency and Regularity Index calculation
            
            [DF,RI,OI] = calDomFreq(cmos_all_data.filt_data, cmos_all_data.frequency);
            temp_DF = DF;
            %temp_DF(temp_DF < 3) = nan;
            temp_DF(temp_DF > 30) = nan;
            mean_DF = nanmean(reshape(temp_DF,[],1));
            std_DF = nanstd(reshape(temp_DF,[],1));
            temp_DF(temp_DF > (mean_DF + std_DF)) = nan;
            temp_DF(temp_DF < (mean_DF - std_DF)) = nan;
            
            temp_OI = OI;
            temp_RI = RI;
            temp_RI = temp_RI .* cmos_all_data.mask;
            temp_DF = temp_DF .* cmos_all_data.mask;
            temp_OI = temp_OI .* cmos_all_data.mask;
            msg = strcat('Dominant Frequency is: ', num2str(nanmedian(nanmedian(temp_DF))));
            disp(msg);
            
            msg = strcat('Regularity Index is: ', num2str(nanmedian(nanmedian(temp_RI))));
            disp(msg);
            
            msg = strcat('Organization Index is: ', num2str(nanmedian(nanmedian(temp_OI))));
            disp(msg);
            
            cmos_all_data.df_map = temp_DF;
            cmos_all_data.ri_map = temp_RI;
            cmos_all_data.oi_map = temp_OI;
           
            
            if debug_mode
                message = strcat('7)DF, RI, and OI calculated');
                disp(message);
            end
            
%             %Step 8: Cycle length calculation
%             CL = calculate_cycle_length(cmos_all_data);
%             cmos_all_data.cycle_length = CL;
%             
%             if debug_mode
%                 message = strcat('8)Cycle Length calculated');
%                 disp(message);
%             end
            
            
            %Step 9A: Generate phase data and calculate wavefronts
            cmos_data = cmos_all_data.filt_data;
            data_mask = repmat(cmos_all_data.mask, [1 1 size(cmos_data,3)]);
            cmos_data = cmos_data .* data_mask;
            hilbert_data = reshape(cmos_data,[],size(cmos_data,3)) - repmat(mean(reshape(cmos_data,[],size(cmos_data,3)),2),[1 size(cmos_data,3)]);
            hilbert_data = hilbert(hilbert_data');
            phase_data = -1*angle(hilbert_data)';
            phase_data = reshape(phase_data,size(cmos_data,1),size(cmos_data,2),[]);
            
            cmos_all_data.phase_data = phase_data;
            [wavefronts, wf_count] = count_wavefronts(cmos_all_data, 0);
            cmos_all_data.wavefronts = wavefronts;
            cmos_all_data.wf_count = wf_count;
            
            %Step 9B: Generate Phase Singularity data
            ps_data = extract_phase_singularity(phase_data);
            cmos_all_data.ps_data = ps_data;
            [ps, ps_count] = count_ps(cmos_all_data, 0);
            cmos_all_data.ps = ps;
            cmos_all_data.ps_count = ps_count;
            
           
           %save everything done so far
           save(cmos_all_data.file_name, 'cmos_all_data', '-v7.3');
            
            wf_dynamics = extract_wavefront_dynamics(cmos_all_data,0);
            cmos_all_data.wf_dynamics = wf_dynamics;
            cmos_all_data = extract_ps_dynamics(cmos_all_data,0);
            
           %save everything done so far
           save(cmos_all_data.file_name, 'cmos_all_data', '-v7.3');
    
            
            if debug_mode
                message = strcat('9)Phase Dynamics extracted');
                disp(message);
            end
            
            if j==1
                epi_data = cmos_all_data;
            else
                endo_data = cmos_all_data;
            end
            
            clear cmos_con_data;
            clear cmos_data;
            clear bin_cmos_data;
            clear avg_bin_cmos_data;
            clear over_filt_bin_cmos_data;
            clear drift_over_filt_bin_cmos_data
            clear cmos_all_data;
            clear phase_data;
            clear ps_data;
            clear hilbert_data;
            clear wf_dynamics;
            
%         catch
%             disp(strcat('error processing file...', mat_file_name));
%             continue;
%         end
    end
    
    %Step 10: Extract Dissociation Dynamics
    dissociation_dynamics.ps = extract_ps_dissociation_dynamics(epi_data, endo_data);
    dissociation_dynamics.wf = extract_wf_dissociation_dynamics(epi_data, endo_data);
    dissociation_dynamics.df = extract_df_dissociation_dynamics(epi_data, endo_data);
    
    if debug_mode
        message = strcat('10)Dissociation Dynamics Extracted');
        disp(message);
    end
    
    %Step 11: Save the processed data
    epi_data.dissociation_dynamics = dissociation_dynamics;
    cmos_all_data = epi_data;
    save(cmos_all_data.file_name, 'cmos_all_data', '-v7.3');
    
    endo_data.dissociation_dynamics = dissociation_dynamics;
    cmos_all_data = endo_data;
    save(cmos_all_data.file_name, 'cmos_all_data', '-v7.3');
    
    
    if debug_mode
        message = strcat('11A)Completed basic processing  and saved data files...', epi_data.file_name);
        disp(message);
        message = strcat('11B)Completed basic processing  and saved data files...', endo_data.file_name);
        disp(message);
    end
    
    clear epi_data;
    clear endo_data;
    clear cmos_all_data;
    
end

if debug_mode
    message = strcat('12)Completed processing of the experiment...', directory);
    disp(message);
end

