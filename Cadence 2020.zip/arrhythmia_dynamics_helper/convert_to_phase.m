function phase_data = convert_to_phase(cmos_data)

hilbert_data = reshape(cmos_data,[],size(cmos_data,3)) - repmat(mean(reshape(cmos_data,[],size(cmos_data,3)),2),[1 size(cmos_data,3)]);
hilbert_data = hilbert(hilbert_data');
phase_data = -1*angle(hilbert_data)';
phase_data = reshape(phase_data,size(cmos_data,1),size(cmos_data,2),[]);

end

