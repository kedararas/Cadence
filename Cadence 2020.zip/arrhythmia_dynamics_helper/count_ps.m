function [ps, ps_count] = count_ps(cmos_all_data, video_mode)

ps_data = cmos_all_data.ps_data;
wavefronts = cmos_all_data.wavefronts;

% PS incidence Count
num_frames = size(ps_data,3);
ps = cell(2,num_frames);
ps_count = zeros(2,num_frames);
for i=1:num_frames
    ps_frame = round(squeeze(ps_data(:,:,i)));
    [p_rows,p_cols] = find(ps_frame == 1);
    p_val = ones(size(p_rows,1),1);
    [n_rows,n_cols] = find(ps_frame == -1);
    n_val = ones(size(n_rows,1),1)*-1; 
    ps_points = [p_cols,p_rows,p_val;n_cols,n_rows,n_val];
    
    threshold = 3; %proximity threshold
    wf_ps_points = tag_ps_to_wf(ps_points, wavefronts{2,i}, threshold);
    
    ps{1,i} = wf_ps_points;
    ps{2,i} = ps_points;
    ps_count(1,i) = size(wf_ps_points,1);
    ps_count(2,i) = size(ps_points,1);
    
    
end

% if video_mode
%     data.bgimage = cmos_all_data.bgimage;
%     data.phase_data = cmos_all_data.phase_data;
%     data.ps_data = cmos_all_data.ps_data;
%     data.wavefronts = cmos_all_data.wavefronts;
%     data.ps = ps;
%     video_file = 'flip-endo-test-v2';
%     generate_phase_video(data, 600, 800, video_file);
% end

