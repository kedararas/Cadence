function [WFfront,WFcount] = count_wavefronts(cmos_all_data, video_mode)


phase_data = cmos_all_data.phase_data;
%% Calculate Wavefront***
level=pi/2; % wavefront definition
Wave={};
WFfront = [];
q=1;
for w=1:1: size(phase_data,3) % loop through time
    %Step 1: Use contour algorithm to calculate wavefronts
    testWave=contourcs(phase_data(:,:,w), [level level]);
    
    %Step 2: Remove any wavefronts <10 pixels in length - noise filter
    threshWave=10;  % change this value to modify wavefront visualization
    l=1;
    
    for c=1:size(testWave,1)
        wf_size(c) = testWave(c,:).Length;
        if testWave(c,:).Length>threshWave
            Wave{l}=[testWave(c,:).X; testWave(c,:).Y];
            l=l+1;
        end
    end
    
    %Step 3: Remove and separate wavefronts based on large spatial gradient
    [px, py]=gradient(phase_data(:,:,w));
    spaceGrad=max(abs(px),abs(py));
    [testerx, testery]=find(spaceGrad>1);
    test=[testery, testerx];
    segWave={};
    index=1;
    for r=1:size(Wave,2) % loop through all waves in contour structure
        X=Wave{1,r};
        tempX_floor=floor(X'); % test both floor and ceiling to deal with rounding errors
        tempX_ceil=ceil(X');
        testcomp_floor=ismember(tempX_floor, test, 'rows'); % test logical for points along large spatial gradient
        testcomp_ceil=ismember(tempX_ceil, test, 'rows');
        testcomp=max(testcomp_ceil, testcomp_floor);
        testcomp=testcomp';
        Y=X(:,~testcomp);
        
        %Separate non connected vectors
        Yshift=Y(:,2:end);
        dist=sqrt((Yshift(1,:)-Y(1,1:end-1)).^2 + (Yshift(2,:)-Y(2,1:end-1)).^2);
        segmentpts= find(dist>5);
        if isempty(segmentpts)
            segWave{index}=Y;
            index=index+1;
        else
            segWave{index}=Y(:,1:segmentpts(1)); index=index+1;
            if length(segmentpts)>1
                for ii=1:length(segmentpts)-1
                    segWave{index}=Y(:,segmentpts(ii)+1:segmentpts(ii+1));
                    index=index+1;
                end
            end
            segWave{index}=Y(:,segmentpts(end)+1:end);
            index=index+1;
        end
        
    end
    
    
    
    num_wf = size(segWave,2);
    wf_count = 0;
    newsegWave = {};
    modified_wf_size = [];
    for i = 1:num_wf
        if ~isempty(segWave{1,i}) && size(segWave{1,i},2) >= 20
            %if ~isempty(segWave{1,i})
                modified_wf_size(i) = size(segWave{1,i},2);
                wf_count = wf_count + 1;
                wf = segWave{1,i};
                if wf(1,1) == wf(1,end) && wf(2,1) == wf(2,end)
                    newsegWave{1,wf_count} = wf(:,1:end-1);
                else
                    newsegWave{1,wf_count} = segWave{1,i};
                end
            %end 
        end
    end
    WFfront{1,q}=newsegWave;
    WFfront{2,q}=segWave(~cellfun('isempty',segWave));
    if ~isempty(modified_wf_size)
        modified_wf_count = sum(modified_wf_size >= 40);
    else
        modified_wf_count = 0;
    end
    WFcount(1,q) = modified_wf_count;
    WFcount(2,q) = wf_count;
    q=q+1;
    Wave={};
    
    
end

% Plot results
if video_mode
    fig = figure;
    video_file = cmos_all_data.file_name;
    video_file = strrep(video_file, '.mat', '-phase.mp4');
    video_file = strrep(video_file, '/arrhythmia/','/arrhythmia/movies/');
    writerObj = VideoWriter(video_file, 'MPEG-4');
    writerObj.FrameRate = 20; % change this value to modify speed of movie
    open(writerObj);
    movegui(fig,'center');
    set(gcf, 'color', [1 1 1]);
    
    image_file = strrep(video_file, '.mp4', '.png');
    image_file = strrep(image_file, '/movies/','/images/phase/');
    
    frame_size = size(phase_data,3);
    if frame_size > 4000
        frame_size = 4000;
    end
    for i = 1:1:frame_size
        G = cmos_all_data.bgimage;
        image(G);
        hold on;
        Mframe = phase_data(:,:,i);
        contourf(Mframe, 32, 'LineStyle', 'none');
        colormap jet;
        %contourcbar;
        caxis([-pi pi])
        %axis image
        axis off
        hold on
        
        if exist('segWave','var')
            segWave=WFfront{1,i};
            for pp=1:size(segWave,2)
                WF=segWave{1,pp};
                plot(WF(1,:), WF(2,:), 'w', 'LineWidth', 2);
            end
        end
        pause(.001)
        hold off
        frame = getframe(gcf);
        writeVideo(writerObj,frame);
        
%         if i < 10
%             prefix = strcat('-000',num2str(i), '.png');
%         elseif i < 100
%             prefix = strcat('-00',num2str(i), '.png');
%         elseif i < 1000
%             prefix = strcat('-0',num2str(i), '.png');
%         else
%             prefix = strcat('-',num2str(i),'.png');
%         end
%         test_file = strrep(image_file, '.png', prefix);
%         saveas(fig, test_file);
        
    end
    close(fig);
    close(writerObj);
    close all;
end


%Step 3: Generate Phase Activation Map (activation is pi/2)
%     num_frames = size(phase_data,3);
%     phase_act_data = nan(100,100,num_frames);
%     for i = 1:size(phase_data,3)
%         phase_frame = round(squeeze(phase_data(:,:,i)).* 10)/10;
%         phase_mask = phase_frame;
%         phase_mask(~isnan(phase_mask)) = 1;
%         phase_frame(phase_frame ~= 1.6) = 0;
%         phase_frame(phase_frame == 1.6) = 1;
%         phase_frame = phase_frame .* phase_mask;
%         phase_act_data(:,:,i) = phase_frame;
%     end

message = strcat('Extracted Wavefront Count');
disp(message);

end

