function wavebreaks = create_ps_objects(ps_matrix)
wavebreaks = [];
if ~isempty(ps_matrix)
    num_frames = size(ps_matrix,2);
    wavebreaks = cell(1,num_frames);
    for i=1:num_frames
        ps_list = ps_matrix{1,i};
        object_list = [];
        if ~isempty(ps_list)
            num_ps = size(ps_list,1);
            for j=1:num_ps
                ps_locations = ps_list(j,:);
                ps = Phase_Singularity(i,j);
                ps.location = [ps_locations(1,1), ps_locations(1,2)];
                ps.charge = ps_locations(1,3);
                ps.wavefront = [i, ps_locations(1,6)];
                ps.lifespan = [];
                ps.path = [];
                object_list{j,1} = ps;
            end
        end
        wavebreaks{1,i} = object_list;
    end
end


