function wavefronts = create_wavefront_objects(wavefront_list, threshold)
wavefronts = [];
if ~isempty(wavefront_list)
    num_frames = size(wavefront_list,2);
    wavefronts = cell(1,num_frames);
    for i=1:num_frames
        wf_list = wavefront_list{1,i};
%         if i==44
%             disp('found');
%         end
        object_list = [];
        if ~isempty(wf_list)
            num_wf = size(wf_list,2);
            wf_counter = 1;
            for j=1:num_wf
                location = wf_list{1,j}';
                 length = size(location,1);
                 if length >= threshold
                     wf = Wavefront(i,wf_counter);
                     wf.location = location;
                     wf.lifespan = [];
                     wf.path = [];
                     wf.length = length;
                     object_list{wf_counter,1} = wf;
                     wf_counter = wf_counter + 1;
                 end
            end
        end
        wavefronts{1,i} = object_list;
    end
end


