function wf_dist = evaluate_frechet(epi, endo)
num_frames = size(epi,2);
wf_dist = cell(2,num_frames);

for i=1:num_frames
    epi_wf = epi{2,i};
    endo_wf = endo{2,i};
    
    if isempty(epi_wf) || isempty(endo_wf)
        continue; %nothing to compare
    end
    
    epi_size = size(epi_wf,2);
    endo_size = size(endo_wf,2);
    
    relative_dist = nan(epi_size, endo_size);
    sorted_index = nan(epi_size, endo_size);
    sorted_dist = nan(epi_size, endo_size);
    data = cell(1,3);
    for j=1:epi_size
        epi_wf_j = epi_wf{1,j}';
        for k=1:endo_size
            endo_wf_k = endo_wf{1,k}';
            %frech_dist = frechet(epi_wf_j(:,1), epi_wf_j(:,2), endo_wf_k(:,1), endo_wf_k(:,2));
            [frech_dist, ~] = DiscreteFrechetDist(epi_wf_j, endo_wf_k);
            if ~isempty(frech_dist)
                relative_dist(j,k) = frech_dist;
            else
                relative_dist(j,k) = -Inf;
            end
        end
        [sorted_dist(j,:), sorted_index(j,:)] = sortrows(relative_dist(j,:)');
    end
    data{1,1} = relative_dist;
    data{1,2} = sorted_dist;
    data{1,3} = sorted_index;
    
    [min_val, min_index] = min(sorted_dist(:,1));
    metric(1,1) = min_val;
    metric(1,2) = min_index;
    metric(1,3) = sorted_index(min_index,1);
    
    wf_dist{1,i} = data;
    wf_dist{2,i} = metric;
 
end




