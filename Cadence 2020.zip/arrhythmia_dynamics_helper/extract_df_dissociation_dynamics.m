function dissociation_dynamics = extract_df_dissociation_dynamics(epi_data, endo_data)

[num_rows, num_cols] = size(epi_data.df_map);

df_count = 0;
ri_count = 0;
oi_count = 0;
df_union_count = 0;
ri_union_count = 0;
oi_union_count = 0;

epi_df = epi_data.df_map;
epi_ri = epi_data.ri_map;
epi_oi = epi_data.oi_map;

endo_df = fliplr(endo_data.df_map);
endo_ri = fliplr(endo_data.ri_map);
endo_oi = fliplr(endo_data.oi_map);

df_mask = epi_df .* endo_df;
df_mask(~isnan(df_mask)) = 1;

% ri_mask = epi_ri .* endo_ri;
% ri_mask(~isnan(ri_mask)) = 1;
% 
% oi_mask = epi_oi .* endo_oi;
% oi_mask(~isnan(oi_mask)) = 1;

for i=1:num_rows
    for j=1:num_cols
        if ~isnan(df_mask(i,j))
            if round(epi_df(i,j)*10)/10 == round(endo_df(i,j)*10)/10 %spatial df match
                df_count = df_count + 1;
            end
            df_union_count = df_union_count + 1;
        
            if round(epi_ri(i,j)*10)/10 == round(endo_ri(i,j)*10)/10 %spatial ri match
                ri_count = ri_count + 1;
            end
            ri_union_count = ri_union_count + 1;
        
            if round(epi_oi(i,j)*10)/10 == round(endo_oi(i,j)*10)/10 %spatial oi match
                oi_count = oi_count + 1;
            end
            oi_union_count = oi_union_count + 1;
        end
    end
end

if df_count > 0
    r_1 = (df_count/df_union_count);
    
else
    r_1 = nan;
end

if ri_count > 0
    r_2 = (ri_count/ri_union_count);
else
    r_2 = nan;
end

if oi_count > 0
    r_3 = (oi_count/oi_union_count);
else
    r_3 = nan;
end

disp(strcat(num2str(r_1), ',', num2str(r_2), ',',num2str(r_3)));
dissociation_dynamics = [r_1,r_2,r_3];




