function ps_dissociation_dynamics = extract_ps_dissociation_dynamics(epi_data, endo_data)


epi_list = epi_data.ps_dynamics.path;
endo_list = endo_data.ps_dynamics.path;

num_epi_ps = size(epi_list,1);
num_endo_ps = size(endo_list,1);
df = median(endo_data.df_map, 'all', 'omitnan');
cycle_length = round(1000/df);

ps_dissociation_dynamics = [];

for i=1:num_epi_ps
    epi_meta_data = epi_list{i,1};
    epi_ps_path = epi_list{i,2};
    
    for j=1:num_endo_ps
        endo_meta_data = endo_list{j,1};
        if endo_meta_data(1,1) <  (epi_meta_data(1,1)-25)
            continue;
        elseif endo_meta_data(1,1) >  (epi_meta_data(1,1)+25)
            break;
        end
        endo_ps_path = endo_list{j,2};
        endo_ps_path(:,3) = 100 - endo_ps_path(:,3);
        
        euclidean_dist = pdist2(epi_ps_path(:,3:4), endo_ps_path(:,3:4), 'euclidean');
        
        if median(euclidean_dist) <= 10
            if isempty(ps_dissociation_dynamics)
               ps_dissociation_dynamics = [epi_meta_data, endo_meta_data, median(euclidean_dist, 'all')];
            else
                ps_dissociation_dynamics(end+1,:) = [epi_meta_data, endo_meta_data, median(euclidean_dist, 'all')];
            end
            
%             figure
%             hold on;
%             axis fill
%             xlim([0 100]);
%             ylim([0 100]);
%             axis off;
%             plot(epi_ps_path(:,3),epi_ps_path(:,4), 'Color', rgb('Blue'), 'LineWidth', 3);
%             plot(endo_ps_path(:,3),endo_ps_path(:,4), 'Color', rgb('Red'), 'LineWidth', 3);
%             disp(median(euclidean_dist, 'all'));
%             close all;
            
        end
    end
end






