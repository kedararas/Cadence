function cmos_all_data = extract_ps_dynamics(cmos_all_data,debug_mode)


%Identify ps tagged to individual wavefronts
[ps, ps_count] = count_ps(cmos_all_data, debug_mode);
cmos_all_data.ps = ps;
cmos_all_data.ps_count = ps_count;

%PS metrics
ps_dynamics = [];
ps_dynamics.ps_count = ps_count;
ps_dynamics.ps_info = [];
ps_dynamics.path = [];

% PS Tracking
ps_matrix = create_ps_objects(cmos_all_data.ps);
num_frames = size(ps_matrix,2);

for i=1:num_frames
    
    ps_list = ps_matrix{1,i};
    if ~isempty(ps_list)
        num_ps = size(ps_list,1);
        
        for j=1:num_ps %iterate through every ps in a frame
            current_ps_list = ps_list;
            ps = ps_list{j,1};
            disp(strcat(int2str(i), '-', int2str(j)));
            
            %set birthday if needed
            if isempty(ps.birthday)
                ps.birthday = [ps.frame,ps.index];
                ps.lifespan = [i,0,i];
                ps.path = [i,j,ps.location];
                ps.wf_path = [ps.wavefront];
                ps.distance = 0;
                ps.displacement = 0;
                disp('new');
            else
                %no double dipping
                disp('taken');
                continue;
            end
            
%             if i == 2 && j == 9
%                 disp('resolve');
%             end
            
            
            for k=i+1:num_frames %compare with the future frames 
                if ~isempty(ps_matrix{1,k})
                    next_ps_list = ps_matrix{1,k}; %list of ps to compare
                    
                    %Choose an appropriate ps candidate in case
                    %there is more than one possible candidate
                    [ps_status, ps_cand] = choose_ps_cand(ps, current_ps_list, next_ps_list);
                    
                    switch ps_status
                        case 'ALIVE'
                            ps.lifespan(1,2) = ps.lifespan(1,2) + 1; % increment life span
                            ps.lifespan(1,3) = k;
                            ps.path = [ps.path; ps_cand.frame, ps_cand.index, ps_cand.location]; %add new ps to the path
                            ps.distance = ps.distance + pdist([ps.location(1,1), ps.location(1,2); ps_cand.location(1,1), ps_cand.location(1,2)], 'euclidean');
                            ps.displacement = pdist([ps.path(1,3),ps.path(1,4);ps.path(end,3),ps.path(end,4)], 'euclidean');
                            ps.wf_path = [ps.wf_path; ps_cand.wavefront];
%                             if ps.frame == 20
%                                 disp('resolve');
%                             end
                            ps_matrix{1,ps.frame}{ps.index,1} = ps;
                            
                            current_ps_list = next_ps_list; % newly linked ps list
                            ps_cand.lifespan = ps.lifespan;
                            ps_cand.path = ps.path;
                            ps_cand.distance = ps.distance;
                            ps_cand.displacement = ps.displacement;
                            ps_cand.wf_path = ps.wf_path;
                            ps_cand.birthday = ps.birthday;
                            ps = ps_cand; % newly linked ps
%                             if ps_cand.frame == 20
%                                 disp('resolve');
%                             end
                            ps_matrix{1,ps_cand.frame}{ps_cand.index,1} = ps_cand;
                            
                        case 'EXPIRED'
                            if ~isempty(ps.path)
                                num_links = size(ps.path,1);
                                for path_counter=1:num_links
                                    frame = ps.path(path_counter,1);
                                    index = ps.path(path_counter,2);
%                                     if frame == 20
%                                         disp('resolve');
%                                     end
                                    ps_matrix{1,frame}{index,1}.lifespan = ps.lifespan;
                                    ps_matrix{1,frame}{index,1}.path = ps.path;
                                    ps_matrix{1,frame}{index,1}.distance = ps.distance;
                                    ps_matrix{1,frame}{index,1}.displacement = ps.displacement;
                                    ps_matrix{1,frame}{index,1}.wf_path = ps.wf_path;
                                    ps_matrix{1,frame}{index,1}.birthday = ps.birthday;
                                end
                            end
                            ps_dynamics = update_ps_database(ps_dynamics, ps);
                            break;
                    end
                else
                    if ~isempty(ps.path)
                        num_links = size(ps.path,1);
                        for path_counter=1:num_links
                            frame = ps.path(path_counter,1);
                            index = ps.path(path_counter,2);
%                             if frame == 20
%                                 disp('resolve');
%                             end
                            ps_matrix{1,frame}{index,1}.lifespan = ps.lifespan;
                            ps_matrix{1,frame}{index,1}.path = ps.path;
                            ps_matrix{1,frame}{index,1}.distance = ps.distance;
                            ps_matrix{1,frame}{index,1}.displacement = ps.displacement;
                            ps_matrix{1,frame}{index,1}.wf_path = ps.wf_path;
                            ps_matrix{1,frame}{index,1}.birthday = ps.birthday;
                        end
                    end
                    ps_dynamics = update_ps_database(ps_dynamics, ps);
                    break;
                end
            end
        end
    end
end

cmos_all_data.ps_dynamics = ps_dynamics;







