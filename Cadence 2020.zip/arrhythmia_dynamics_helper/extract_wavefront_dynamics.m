function wavefront_dynamics = extract_wavefront_dynamics(cmos_all_data, debug_mode)

%wavefront metrics
wavefront_dynamics = [];
wavefront_dynamics.wf_count = cmos_all_data.wf_count;
wavefront_dynamics.wf_size_duration = [];
wavefront_dynamics.wf_path = [];
wavefront_dynamics.wf_fractionations = [];
wavefront_dynamics.wf_collisions = [];
wavefront_dynamics.wf_blocks = [];
wavefront_dynamics.wf_breakthroughs = [];
wavefront_dynamics.wf_multiplicity = [];
wavefront_dynamics.wf_repeatability = [];
wavefront_dynamics.wf_reentry = [];
wavefront_dynamics.df = median(cmos_all_data.df_map, 'all', 'omitnan');

% Wavefront Tracking
wavefronts = create_wavefront_objects(cmos_all_data.wavefronts, 20);
num_frames = size(wavefronts,2);

for i=1:num_frames %iterate through every frame % first
    wf_list = wavefronts{1,i};
    if ~isempty(wf_list)
        num_wf = size(wf_list,1);
        
        for j=1:num_wf %iterate through every wavefront in a frame  %second
            current_wf_list = wf_list;
            wf = wf_list{j,1};
            disp(strcat(int2str(i), '-', int2str(j)));
                      
            %set birthday if needed 
            if isempty(wf.birthday)
                wf.birthday = [wf.frame,wf.index];
                wf.lifespan = [i,0,i];
                wf.path = [i,j];
                current_neighbors = get_wf_neighbors(wf, current_wf_list, 10, debug_mode);
                if ~isempty(current_neighbors)
                    current_neighbors(:,3) = wf.frame;
                    current_neighbors(current_neighbors(:,2) == wf.index,:) = [];
                    if ~isempty(current_neighbors)
                        wf.neighbors{1,1} = current_neighbors;
                    end
                end
                disp('new');
            else
                %no double dipping
                disp('taken');
                continue;
            end
            
            if i==323 && j==3
                disp('debug');
            end
            
            for k=i+1:num_frames %compare with the future frames %Third  
                
                if ~isempty(wavefronts{1,k})
                    next_wf_list = wavefronts{1,k}; %list of wf to compare
                    next_wf_black_list = [];
                    
                    %Choose an appropriate wavefront candidate in case
                    %there is more than one possible candidate
                    [wf_status, wf_cand, wf_mate, wf_child] = choose_wf_cand(wf, current_wf_list, next_wf_list, next_wf_black_list, debug_mode);
                    
                    switch wf_status
                        case 'ALIVE'
                            neighbors = get_wf_neighbors(wf_cand, next_wf_list, 10, debug_mode);
                            if ~isempty(neighbors)
                                neighbors(:,3) = wf_cand.frame;
                                neighbors(neighbors(:,2) == wf_cand.index,:) = [];
                            end
                           
                            wf.lifespan(1,2) = wf.lifespan(1,2) + 1; % increment life span
                            wf.lifespan(1,3) = k;
                            wf.path = [wf.path; wf_cand.frame, wf_cand.index]; %add new wf to the path
                            if size(wf_cand.length,1) > 1
                                disp('resolve situation');
                            end
                            wf.length = [wf.length; median(wf_cand.length)];
                            if ~isempty(neighbors)
                                if ~isempty(wf.neighbors)
                                    wf.neighbors{size(wf.neighbors,1)+1,1} = neighbors;
                                else
                                    wf.neighbors{1,1} = neighbors;
                                end
                            end
                            wavefronts{1,wf.frame}{wf.index,1} = wf;
                            
                            current_wf_list = next_wf_list; % newly linked wf list
                            wf_cand.lifespan = wf.lifespan;
                            wf_cand.path = wf.path;
                            wf_cand.neighbors = wf.neighbors;
                            wf_cand.birthday = wf.birthday;
                            wf_cand.length = wf.length;
                            wf = wf_cand; % newly linked wf
                            wavefronts{1,wf_cand.frame}{wf_cand.index,1} = wf_cand;
                            
                        case 'EXPIRED'
                            if ~isempty(wf.path)
                                num_links = size(wf.path,1);
                                wf.cause_of_death = 'EXPIRED';
                                for path_counter=1:num_links
                                    frame = wf.path(path_counter,1);
                                    index = wf.path(path_counter,2);
                                    wavefronts{1,frame}{index,1}.cause_of_death = wf.cause_of_death;
                                    wavefronts{1,frame}{index,1}.lifespan = wf.lifespan;
                                    wavefronts{1,frame}{index,1}.path = wf.path;
                                    wavefronts{1,frame}{index,1}.length = wf.length;
                                    wavefronts{1,frame}{index,1}.birthday = wf.birthday;
                                    wavefronts{1,frame}{index,1}.neighbors = wf.neighbors;
                                end
                            end
                            wavefront_dynamics = update_wf_database(wavefront_dynamics, wf, wavefronts);
                            break;
                            
                        case 'FRAGMENTED'
                            wf.cause_of_death = 'FRAGMENTED';
                            %book keeping for the children
                            num_child = size(wf_child,1);
                            child_info = [];
                            for c=1:num_child
                                    child = wf_child{c,1};
                                    child.parent = [wf.frame, wf.index];
                                    wavefronts{1,k}{child.index,1} = child;
                            end
     
                            %book keeping for single parent
                            if ~isempty(wf.path)
                                num_links = size(wf.path,1);
                                for path_counter=1:num_links
                                    frame = wf.path(path_counter,1);
                                    index = wf.path(path_counter,2);
                                    wavefronts{1,frame}{index,1}.cause_of_death = wf.cause_of_death;
                                    wavefronts{1,frame}{index,1}.lifespan = wf.lifespan;
                                    wavefronts{1,frame}{index,1}.path = wf.path;
                                    wavefronts{1,frame}{index,1}.length = wf.length;
                                    wavefronts{1,frame}{index,1}.birthday = wf.birthday;
                                    wavefronts{1,frame}{index,1}.neighbors = wf.neighbors;
                                    wavefronts{1,frame}{index,1}.child = child_info;
                                    wf.child = child_info;
                                end
                            end
                             wavefront_dynamics = update_wf_database(wavefront_dynamics, wf, wavefronts);
                            break;
                            
                        case 'MERGED'
                            wf.cause_of_death = 'MERGED';
                            
                            %book keeping for the child
                            wf_child.parent = [wf.frame, wf.index; wf_mate.frame, wf_mate.index];
                            wavefronts{1,wf_child.frame}{wf_child.index,1} = wf_child;
                            
                            %book keeping for the parent 1
                            wf_mate.mate = [wf.frame, wf.index];
                            wf_mate.child = [wf_child.frame, wf_child.index];
                            wf_mate.cause_of_death = 'MERGED';
                            wavefronts{1,wf_mate.frame}{wf_mate.index,1} = wf_mate;
                            
                            %book keeping for the parent 2
                            if ~isempty(wf.path)
                                num_links = size(wf.path,1);
                                for path_counter=1:num_links
                                    frame = wf.path(path_counter,1);
                                    index = wf.path(path_counter,2);
                                    wavefronts{1,frame}{index,1}.cause_of_death = wf.cause_of_death;
                                    wavefronts{1,frame}{index,1}.lifespan = wf.lifespan;
                                    wavefronts{1,frame}{index,1}.path = wf.path;
                                    wavefronts{1,frame}{index,1}.length = wf.length;
                                    wavefronts{1,frame}{index,1}.birthday = wf.birthday;
                                    wavefronts{1,frame}{index,1}.child = [wf_child.frame, wf_child.index];
                                    wavefronts{1,frame}{index,1}.mate = [wf_mate.frame, wf_mate.index];
                                    wavefronts{1,frame}{index,1}.neighbors = wf.neighbors;
                                    wf.child = [wf_child.frame, wf_child.index];
                                    wf.mate = [wf_mate.frame, wf_mate.index];
                                end
                            end
                            wavefront_dynamics = update_wf_database(wavefront_dynamics, wf, wavefronts);
                            break;
                    end
                else
                    if ~isempty(wf.path)
                        num_links = size(wf.path,1);
                        wf.cause_of_death = 'EXPIRED';
                        for path_counter=1:num_links
                            frame = wf.path(path_counter,1);
                            index = wf.path(path_counter,2);
                            wavefronts{1,frame}{index,1}.cause_of_death = wf.cause_of_death;
                            wavefronts{1,frame}{index,1}.lifespan = wf.lifespan;
                            wavefronts{1,frame}{index,1}.path = wf.path;
                            wavefronts{1,frame}{index,1}.length = wf.length;
                            wavefronts{1,frame}{index,1}.birthday = wf.birthday;
                            wavefronts{1,frame}{index,1}.neighbors = wf.neighbors;
                        end
                    end
                    wavefront_dynamics = update_wf_database(wavefront_dynamics, wf, wavefronts);
                    break;
               end
            end
        end
    end
end





