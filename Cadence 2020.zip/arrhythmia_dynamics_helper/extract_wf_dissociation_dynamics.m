function wf_dissociation_dynamics = extract_wf_dissociation_dynamics(epi_data,endo_data)

epi_wavefronts = epi_data.wavefronts;
endo_wavefronts = endo_data.wavefronts;

epi_list = epi_data.wf_dynamics.wf_path;
endo_list = endo_data.wf_dynamics.wf_path;

num_epi_wf = size(epi_list,1);
num_endo_wf = size(endo_list,1);
df = median(endo_data.df_map, 'all', 'omitnan');
cycle_length = round(1000/df);

wf_dissociation_dynamics = [];

for i=1:num_epi_wf
    epi_meta_data = epi_list{i,1};
    epi_wf_path = epi_list{i,2};
    epi_path_length = size(epi_wf_path,1);
    first_list = cell(epi_path_length,1);
    for epi_i=1:epi_path_length
        first_list{epi_i,1} = round(epi_wavefronts{1,epi_wf_path(epi_i,1)}{1,epi_wf_path(epi_i,2)}');
    end
    
    for j=1:num_endo_wf
        endo_meta_data = endo_list{j,1};
        if endo_meta_data(1,1) <  (epi_meta_data(1,1)-cycle_length)
            continue;
        elseif endo_meta_data(1,1) >  (epi_meta_data(1,1)+cycle_length)
            break;
        end
        endo_wf_path = endo_list{j,2};
        endo_path_length = size(endo_wf_path,1);
        second_list = cell(endo_path_length,1);
        for k=1:endo_path_length
            segWave = round(endo_wavefronts{1,endo_wf_path(k,1)}{1,endo_wf_path(k,2)}');
            segWave(:,1) = 100-segWave(:,1);
            second_list{k,1} = segWave;
        end
        
        frech_dist = get_frechet_distance_single(first_list, second_list);
        [dtw_dist, euclidean_dist] = get_dtw_distance_single(first_list, second_list);
        if median(frech_dist) <= 30 && median(euclidean_dist) <= 25
            if isempty(wf_dissociation_dynamics)
               wf_dissociation_dynamics = [epi_meta_data, endo_meta_data, median(frech_dist), median(euclidean_dist)];
            else
                wf_dissociation_dynamics(end+1,:) = [epi_meta_data, endo_meta_data, median(frech_dist), median(euclidean_dist)];
            end
            
%             debug_temporal_wavefront(first_list, second_list);
%             disp(median(euclidean_dist));
%             disp(median(frech_dist));
%             close all;
            
        end
    end
end






