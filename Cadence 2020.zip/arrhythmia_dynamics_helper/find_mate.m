function mate = find_mate(wf, wf_cand, wf_list, debug_mode)
mate = [];
if ~isempty(wf_list)
    num_wf = size(wf_list, 1);
    for i=1:num_wf
        mate_cand = wf_list{i,1};
        if ~isempty(wf_cand) && (mate_cand.index ~= wf_cand.index)
            intersection = InterX(wf.location', mate_cand.location');
            if ~isempty(intersection)
                if isempty(mate)
                    mate = [mate_cand.frame, mate_cand.index];
                     
                else
                    mate = [mate; mate_cand.frame, mate_cand.index];
                end
            end
        end
    end
end

if debug_mode
    if ~isempty(wf_list)
        num_orig_wf = size(wf_list,1);
        f1 = figure;
        hold on;
        axis fill
        axis off;
        for wf_count=1:num_orig_wf
            segWave = wf_list{wf_count,1}.location;
            if ~isempty(segWave)
                plot(segWave(:,1),segWave(:,2), 'Color', rgb('Black'), 'LineWidth', 3);
            end
        end
        if ~isempty(wf)
            plot(wf.location(:,1),wf.location(:,2), 'Color', rgb('Blue'), 'LineWidth', 3);
        end
        if ~isempty(mate)
            for j=1:size(mate,1)
                segWave = wf_list{mate(j,2),1}.location;
                if ~isempty(segWave)
                    plot(segWave(:,1),segWave(:,2), 'Color', rgb('Green'), 'LineWidth', 3);
                end
            end
        end
    end
end


