function [relative_dtw_dist, relative_euclidean_dist] = get_dtw_distance(first_list, second_list)
relative_dtw_dist = [];
relative_euclidean_dist = [];
if isempty(first_list) || isempty(second_list)
    return; %nothing to compare
end

first_size = size(first_list,1);
second_size = size(second_list,1);

relative_dist = nan(first_size, second_size);
for j=1:first_size
    first_wf_j = first_list{j,1};
    for k=1:second_size
        second_wf_k = second_list{k,1};
        euclidean_dist = median(pdist2(first_wf_j, second_wf_k, 'euclidean'), 'all');
        dtw_dist = dtw(first_wf_j', second_wf_k', 'euclidean');
        if ~isempty(dtw_dist)
            relative_dtw_dist(j,k) = dtw_dist;
        else
            relative_dtw_dist(j,k) = -Inf;
        end
        
        if ~isempty(euclidean_dist)
            relative_euclidean_dist(j,k) = euclidean_dist;
        else
            relative_euclidean_dist(j,k) = -Inf;
        end
    end
end

end

