function [relative_dtw_dist, relative_euclidean_dist] = get_dtw_distance_single(first_list, second_list)
relative_dtw_dist = [];
relative_euclidean_dist = [];
if isempty(first_list) || isempty(second_list)
    return; %nothing to compare
end

num_first_wf = size(first_list,1);
num_second_wf = size(second_list,1);
if num_first_wf > num_second_wf
    num_wf = num_first_wf;
else
    num_wf = num_second_wf;
end

relative_dtw_dist = nan(num_wf,1);
relative_euclidean_dist = nan(num_wf,1);
for i=1:num_wf
    if i <= num_first_wf
        first_wf = first_list{i,1};
    end
    
    if i <= num_second_wf
        second_wf = second_list{i,1};
    end
    
    if ~isempty(first_wf) && ~isempty(second_wf)
        relative_dtw_dist(i,1) = dtw(first_wf', second_wf', 'euclidean');
        relative_euclidean_dist(i,1) = median(diag(pdist2(first_wf, second_wf, 'euclidean')));
    end
end

