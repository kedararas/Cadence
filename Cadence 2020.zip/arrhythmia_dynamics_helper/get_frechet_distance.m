function relative_dist = get_frechet_distance(first_list, second_list)
    relative_dist = [];
    if isempty(first_list) || isempty(second_list)
        return; %nothing to compare
    end
    
    first_size = size(first_list,1);
    second_size = size(second_list,1);
    
    relative_dist = nan(first_size, second_size);
    for j=1:first_size
        first_wf_j = first_list{j,1};
        for k=1:second_size
            second_wf_k = second_list{k,1};
            [frech_dist, ~] = DiscreteFrechetDist(first_wf_j, second_wf_k);
            if ~isempty(frech_dist)
                relative_dist(j,k) = frech_dist;
            else
                relative_dist(j,k) = -Inf;
            end
        end
    end

end

