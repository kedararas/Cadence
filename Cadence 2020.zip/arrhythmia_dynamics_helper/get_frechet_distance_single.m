function relative_dist = get_frechet_distance_single(first_list, second_list)
relative_dist = [];
if isempty(first_list) || isempty(second_list)
    return; %nothing to compare
end

num_first_wf = size(first_list,1);
num_second_wf = size(second_list,1);
if num_first_wf > num_second_wf
    num_wf = num_first_wf;
else
    num_wf = num_second_wf;
end

relative_dist = nan(num_wf,1);
for i=1:num_wf
    if i <= num_first_wf
        first_wf = first_list{i,1};
    end
    
    if i <= num_second_wf
        second_wf = second_list{i,1};
    end
    
    if ~isempty(first_wf) && ~isempty(second_wf)
        relative_dist(i,1) = DiscreteFrechetDist(first_wf, second_wf);
    end
end

