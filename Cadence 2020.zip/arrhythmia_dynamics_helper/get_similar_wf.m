function [wf_cand_list, relative_distance] = get_similar_wf(wf_index, wf_list, next_wf_list, black_list, threshold)

wf_cand_list = [];

if ~isempty(wf_list)
    num_first_wf = size(wf_list,1);
    first_list = cell(num_first_wf, 1);
    for i=1:num_first_wf
        first_list{i,1} = wf_list{i,1}.location;
    end
end

if ~isempty(next_wf_list)
    num_second_wf = size(next_wf_list,1);
    second_list = cell(num_second_wf, 1);
    for i=1:num_second_wf
        second_list{i,1} = next_wf_list{i,1}.location;
    end
end
        
relative_distance = get_frechet_distance(first_list, second_list); %calculate pair wise frechet distance between the two WF lists
%relative_distance = get_dtw_distance(first_list, second_list);
[sorted_dist, sorted_index] = sortrows(relative_distance(wf_index,:)');
counter = 1;
for i=1:size(sorted_index,1)
    %if ~ismember(sorted_index(i,1), black_list)
        if sorted_dist(i,1) <= threshold
            wf_cand_list(counter,:) = [sorted_dist(i,1), sorted_index(i,1), size(next_wf_list{sorted_index(i,1),1}.location,1)];
            counter = counter + 1;
        end
    %end
end

% wf_found = 0;
% counter = 1;
% while ~wf_found
%     [sorted_dist_2,sorted_index_2] = sortrows(relative_distance(:,sorted_index(counter,1)));
%     if sorted_index_2(1,1) == wf_index && ~ismember(sorted_index(counter,1), red_list)
%         wf_cand_list(counter,1) = sorted_dist(1,1);
%         wf_cand_list(counter,2) = sorted_index(1,1);
%         wf_found = 1;
%         break;
%     else
%         wf_cand_list(counter,1) = sorted_dist_2(1,1);
%         wf_cand_list(counter,2) = sorted_index_2(1,1);
%     end
%     counter = counter + 1;
%     if counter > size(sorted_index,1)
%         break;
%     end
% end
    




