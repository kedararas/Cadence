function wf_neighbors = get_wf_neighbors(wf, wf_list, neighbor_threshold, debug_mode)
wf_neighbors = [];

if ~isempty(wf_list) && ~isempty(wf) %basic validation
    num_wf = size(wf_list,1);
    euclidean_relative_distance = nan(num_wf,3);
    wf_counter = 1;
    for i=1:num_wf
        dist = pdist2(wf.location, wf_list{i,1}.location, 'euclidean', 'Smallest', 1);
        euclidean_relative_distance(wf_counter,1) = min(dist);
        euclidean_relative_distance(wf_counter,2) = i;
        euclidean_relative_distance(wf_counter,3) = size(wf_list{i,1}.location,1);
        wf_counter = wf_counter + 1;
    end
    [wf_neighbors, sorted_index] = sortrows(euclidean_relative_distance);
     wf_neighbors(wf_neighbors(:,1)>neighbor_threshold,:) = [];
end

if debug_mode
    if ~isempty(wf_list)
        num_orig_wf = size(wf_list,1);
        f1 = figure;
        hold on;
        axis fill
        axis off;
        for wf_count=1:num_orig_wf
            segWave = wf_list{wf_count,1}.location;
            if ~isempty(segWave)
                plot(segWave(:,1),segWave(:,2), 'Color', rgb('Black'), 'LineWidth', 3);
            end
        end
        if ~isempty(wf)
            plot(wf.location(:,1),wf.location(:,2), 'Color', rgb('Blue'), 'LineWidth', 3);
        end
        if ~isempty(wf_neighbors)
            for i=1:size(wf_neighbors,1)
                segWave = wf_list{wf_neighbors(i,2),1}.location;
                if ~isempty(segWave)
                    plot(segWave(:,1),segWave(:,2), 'Color', rgb('Red'), 'LineWidth', 3);
                end
            end
        end
    end
end

