classdef Phase_Singularity
    
    properties
        wavefront
        lifespan
        frame
        index
        name
        location
        displacement
        distance
        path
        wf_path
        charge
        birthday
     
    end
    
    methods
        function obj = Phase_Singularity(frame, index)
            obj.frame = frame;
            obj.index = index;
            obj.name = strcat(num2str(frame),num2str(index));
        end
        
    end
end

