classdef Wavefront
    
    properties
        parent
        child
        mate
        fling
        neighbors
        lifespan
        frame
        index
        name
        length
        location
        path
        birthday
        cause_of_death
    end
    
    methods
        function obj = Wavefront(frame, index)
            obj.frame = frame;
            obj.index = index;
            obj.name = strcat(num2str(frame),num2str(index));
        end
        
    end
end

