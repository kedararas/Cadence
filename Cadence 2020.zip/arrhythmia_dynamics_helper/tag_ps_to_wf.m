function [ps_locations] = tag_ps_to_wf(ps_points, wavefronts, threshold)

ps_locations = [];
ps_counter = 1;

if ~isempty(wavefronts) && ~isempty(ps_points)
    
    
    %Step 1: Find all ps in close proximity (2 pixels) to the activation
    %wavefronts
    num_wf = size(wavefronts,2);
    num_ps = size(ps_points,1);
    
    wf_points = zeros(num_wf*2,3);
    counter = 1;
    for i=1:num_wf
        wf = wavefronts{1,i};
        wf_points(counter,:) = [wf(1,1), wf(2,1),i];
        wf_points(counter+1,:) = [wf(1,end), wf(2,end),i];
        counter = counter+2;
    end
    
    relative_dist = round(pdist2(wf_points(:,1:2), ps_points(:,1:2)));
    black_list = [];
    %current_charge = [];
    for j=1:num_wf*2
        found = 0;
        [ps_dist, ps_index] = sortrows(relative_dist(j,:)');
        while ~found
            for k=1:num_ps
                cand_ps = ps_index(k,1); % ps could be the closest to current wf
                if (isempty(black_list) || ~ismember(cand_ps,black_list)) ...
                        %&& (isempty(current_charge) || ps_points(cand_ps,3) == current_charge) 
                    [wf_dist, wf_index] = sortrows(relative_dist(:,cand_ps));
                    wf_index(wf_index < j) = []; % remove tagged wf from comparison
                    cand_wf = wf_index(1,1);
                    if cand_wf == j %found wf and ps closest to each other
                        found = 1;
                        ps_locations(ps_counter,1:3) = ps_points(cand_ps,:); %ps col, ps row, ps charge
                        ps_locations(ps_counter,4) = ps_dist(k,1); % wf-ps dist
                        ps_locations(ps_counter,5) = cand_ps;
                        ps_locations(ps_counter,6) = round(cand_wf/2);
                        ps_counter = ps_counter + 1;
                        
                        %remove ps from the list of ps-wf comparisons
                        if isempty(black_list)
                            black_list = cand_ps;
                        else
                            black_list = [black_list; cand_ps];
                        end
                        
                        %set or reset charge
%                         if mod(j,2) == 0
%                             current_charge = [];
%                         else
%                             current_charge = ps_points(cand_ps,3) * -1;
%                         end
                        break;
                    end
                end
            end
            if k==num_ps
                break;
            end
        end
    end
end

if ~isempty(ps_locations)
    ps_locations(ps_locations(:,4) > threshold, :) = [];
end
















