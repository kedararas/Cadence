function ps_dynamics = update_ps_database(ps_dynamics,ps)

%add entry for ps duration, distance, and displacement
if isempty(ps_dynamics.ps_info)
    ps_dynamics.ps_info(1,1) = ps.birthday(1,1);
    ps_dynamics.ps_info(1,2) = ps.birthday(1,2);
    ps_dynamics.ps_info(1,3) = ps.lifespan(1,2);
    ps_dynamics.ps_info(1,4) = ps.distance;
    ps_dynamics.ps_info(1,5) = ps.displacement;
else
    ps_dynamics.ps_info(end+1,:) = [ps.birthday(1,1), ps.birthday(1,2),ps.lifespan(1,2), ps.distance, ps.displacement];
end

%add entry for ps path
if ps.lifespan(1,2) >= 10
    disp(ps.lifespan(1,2))
    if isempty(ps_dynamics.path)
        ps_dynamics.path{1,1} = [ps.birthday(1,1), ps.birthday(1,2), ps.lifespan(1,2)];
        ps_dynamics.path{1,2} = ps.path;
        ps_dynamics.path{1,3} = ps.wf_path;
    else
        counter = size(ps_dynamics.path, 1);
        ps_dynamics.path{counter+1,1} = [ps.birthday(1,1), ps.birthday(1,2), ps.lifespan(1,2)];
        ps_dynamics.path{counter+1,2} = ps.path;
        ps_dynamics.path{counter+1,3} = ps.wf_path;
    end
end



