function wf_dynamics = update_wf_database(wavefront_dynamics,wf, wavefronts)
wf_dynamics = wavefront_dynamics;

%add entry for wf size & duration
if isempty(wf_dynamics.wf_size_duration)
    wf_dynamics.wf_size_duration(1,1) = wf.birthday(1,1);
    wf_dynamics.wf_size_duration(1,2) = wf.birthday(1,2);
    wf_dynamics.wf_size_duration(1,3) = round(median(wf.length));
    wf_dynamics.wf_size_duration(1,4) = wf.lifespan(1,2);
else
    wf_dynamics.wf_size_duration(end+1,:) = [wf.birthday(1,1), wf.birthday(1,2),round(median(wf.length)), wf.lifespan(1,2)];
end

%add entry for wf path
if wf.lifespan(1,2) >= 10
    if isempty(wf_dynamics.wf_path)
        wf_dynamics.wf_path{1,1} = [wf.birthday(1,1), wf.birthday(1,2),round(median(wf.length)), wf.lifespan(1,2)];
        wf_dynamics.wf_path{1,2} = wf.path;
    else
        counter = size(wf_dynamics.wf_path, 1);
        wf_dynamics.wf_path{counter+1,1} = [wf.birthday(1,1), wf.birthday(1,2),round(median(wf.length)), wf.lifespan(1,2)];
        wf_dynamics.wf_path{counter+1,2} = wf.path;
    end
end

%add entry for fragmented wavefront, if so
if strcmp(wf.cause_of_death, 'FRAGMENTED')
    if isempty(wf_dynamics.wf_fractionations)
        wf_dynamics.wf_fractionations(1,1) = wf.birthday(1,1);
        wf_dynamics.wf_fractionations(1,2) = wf.birthday(1,2);
        wf_dynamics.wf_fractionations(1,3) = round(median(wf.length));
        wf_dynamics.wf_fractionations(1,4) = wf.lifespan(1,2);
    else
        wf_dynamics.wf_fractionations(end+1,:) = [wf.birthday(1,1), wf.birthday(1,2), round(median(wf.length)), wf.lifespan(1,2)];
    end
end

%add entry for merged wavefront, if so
if strcmp(wf.cause_of_death, 'MERGED')
    if isempty(wf_dynamics.wf_collisions)
        wf_dynamics.wf_collisions(1,1) = wf.birthday(1,1);
        wf_dynamics.wf_collisions(1,2) = wf.birthday(1,2);
        wf_dynamics.wf_collisions(1,3) = round(median(wf.length));
        wf_dynamics.wf_collisions(1,4) = wf.lifespan(1,2);
    else
        wf_dynamics.wf_collisions(end+1,:) = [wf.birthday(1,1), wf.birthday(1,2), round(median(wf.length)), wf.lifespan(1,2)];
    end
end

%add entry for blocked wavefront, if so
if strcmp(wf.cause_of_death, 'EXPIRED')
    if isempty(wf_dynamics.wf_blocks)
        wf_dynamics.wf_blocks(1,1) = wf.birthday(1,1);
        wf_dynamics.wf_blocks(1,2) = wf.birthday(1,2);
        wf_dynamics.wf_blocks(1,3) = round(median(wf.length));
        wf_dynamics.wf_blocks(1,4) = wf.lifespan(1,2);
    else
        wf_dynamics.wf_blocks(end+1,:) = [wf.birthday(1,1), wf.birthday(1,2), round(median(wf.length)), wf.lifespan(1,2)];
    end
end

%add entry for wf breakthrough,
if isempty(wf.parent) && ~ismember(1,wf.location(:,1) > 90) && ~ismember(1, wf.location(:,2) > 90)...
        && ~ismember(1,wf.location(:,1) < 10) && ~ismember(1, wf.location(:,2) < 10)
    if isempty(wf_dynamics.wf_breakthroughs)
        wf_dynamics.wf_breakthroughs(1,1) = wf.birthday(1,1);
        wf_dynamics.wf_breakthroughs(1,2) = wf.birthday(1,2);
        wf_dynamics.wf_breakthroughs(1,3) = median(wf.length);
        wf_dynamics.wf_breakthroughs(1,4) = wf.lifespan(1,2);
        
    else
        wf_dynamics.wf_breakthroughs(end+1,:) = [wf.birthday(1,1), wf.birthday(1,2), round(median(wf.length)), wf.lifespan(1,2)];
    end
end

repeat_index = check_for_wf_repeatability(wf_dynamics, wf, wavefronts);

%add entry for repeat wavefront pattern, if so
if repeat_index > 0 %wf is not unique
    if  isempty(wf_dynamics.wf_repeatability)
        wf_dynamics.wf_repeatability = [repeat_index, wf.birthday(1,1), wf.birthday(1,2),  round(median(wf.length)), wf.lifespan(1,2)] ;
    else
        wf_dynamics.wf_repeatability(end+1,:) = [repeat_index, wf.birthday(1,1), wf.birthday(1,2),  round(median(wf.length)), wf.lifespan(1,2)];
    end
end

%add entry for unique wavefront path, if so
if repeat_index == 0 && wf.lifespan(1,2) >= 10 %wf is unique
    if  isempty(wf_dynamics.wf_multiplicity)
        wf_dynamics.wf_multiplicity = [wf.birthday(1,1), wf.birthday(1,2), round(median(wf.length)), wf.lifespan(1,2)];
    else
        wf_dynamics.wf_multiplicity(end+1,:) = [wf.birthday(1,1), wf.birthday(1,2),round(median(wf.length)), wf.lifespan(1,2)];
    end
end

%add entry for reentrant wavefront, if so
reentry_index = check_for_wf_reentry(wf, wavefronts, wf_dynamics.df);
if reentry_index == 1 %reentrant wf
    if  isempty(wf_dynamics.wf_reentry)
        wf_dynamics.wf_reentry = [wf.birthday(1,1), wf.birthday(1,2), round(median(wf.length)), wf.lifespan(1,2)];
    else
        wf_dynamics.wf_reentry(end+1,:) = [wf.birthday(1,1), wf.birthday(1,2), round(median(wf.length)), wf.lifespan(1,2)];
    end
end



