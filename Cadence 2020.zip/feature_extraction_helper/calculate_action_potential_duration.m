function apd_times = calculate_action_potential_duration(cmos_data, start_frame, end_frame, act_times, rep_times)

if isempty(act_times)
    act_times = calculate_activation_times(cmos_data, start_frame, end_frame);
end

if isempty(rep_times)
    rep_times = calculate_repolarization_times(cmos_data, start_frame, end_frame);
end

apd_times = rep_times;
num_markers = size(apd_times,3);
for i=1:num_markers
    apd_times(:,:,i) = rep_times(:,:,i) - act_times;
end

end

