function act_times = calculate_activation_times(cmos_data, start_frame, end_frame)

  win_data = cmos_data(:,:,start_frame:end_frame);
  norm_win_data = normalize_data(win_data);
  diff_data = diff(win_data,1,3);
  [~, act_times] = max(diff_data,[],3);
  %val_act_times = act_times;
  
  [num_rows, num_cols, ~] = size(cmos_data);
  act_50 = nan(num_rows, num_cols);
  %act_times_amplitude = nan(num_rows, num_cols);
  
  for m=1:num_rows
      for n=1:num_cols
          if ~isnan(norm_win_data(m,n,1)) 
            win_oap = squeeze(norm_win_data(m,n,:));
            act_50(m,n) = find(win_oap(1:end) >= 0.5,1); %50% amplitude
            
            %act_times_amplitude(m,n) = win_oap(act_times(m,n));
            if win_oap(act_times(m,n)) < 0.2 || win_oap(act_times(m,n)) > 0.6 % validation check for max upstroke
                act_times(m,n) = act_50(m,n);
            end
            
          end
      end
  end
            
%   act_array = zeros(num_rows, num_cols,2);
%   act_array(:,:,1) = act_times;
%   act_array(:,:,2) = act_50;
%   act_data = nanmedian(act_array,3);
  
  %act_times(act_times == 1) = nan;

end

