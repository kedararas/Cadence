function apd_alternans = calculate_apd_alternans(apd_times)
apd_alternans = [];
if ~isempty(apd_times)
    num_beats = size(apd_times,1);
    apd_alternans = cell(num_beats-1,1);
    for i=1:num_beats-1
        apd_alternans{i,1} = apd_times{i+1,1} - apd_times{i,1};
    end
end

end

