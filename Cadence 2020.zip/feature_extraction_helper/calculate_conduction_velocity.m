function local_cv = calculate_conduction_velocity(cmos_data, start_frame, end_frame, act_times)

if isempty(act_times)
    act_times = calculate_activation_times(cmos_data, start_frame, end_frame);
end
local_cv = get_local_cv(act_times);

end

