function rep_times = calculate_repolarization_times(cmos_data, start_frame, end_frame)

%cmos_data = remove_Drift(cmos_data);
win_data = cmos_data(:,:,start_frame:end_frame);
norm_win_data = normalize_data(win_data);

[num_rows, num_cols, ~] = size(cmos_data);
rep_times = nan(num_rows, num_cols,9); % rep10, rep20, rep30,rep40, rep50, rep60, rep70, rep80, rep90

act_times = calculate_activation_times(cmos_data, start_frame, end_frame);

for m=1:num_rows
    for n=1:num_cols
        if ~isnan(norm_win_data(m,n,1)) && ~isnan(act_times(m,n))
            win_oap = squeeze(norm_win_data(m,n,:));
            %[~, max_loc] = max(win_oap);
            
%             if max_loc <= act_times(m,n)
%                 continue; %likely bad data
%             end
           max_loc = act_times(m,n) + 25;
            
%             if m==14 && n==1
%                 disp('found test case');
%             end
            
            rep_10 = find(win_oap(max_loc:end) <= 0.9,1);
            if ~isempty(rep_10)
                rep_times(m,n,1) = max_loc + rep_10;
            end
            
            rep_20 = find(win_oap(max_loc:end) <= 0.8,1);
            if ~isempty(rep_20)
                rep_times(m,n,2) = max_loc + rep_20;
            else
                rep_times(m,n,2) = rep_times(m,n,1);
            end
            
            rep_30 = find(win_oap(max_loc:end) <= 0.7,1);
            if ~isempty(rep_30)
                rep_times(m,n,3) = max_loc + rep_30;
            else
                rep_times(m,n,3) = rep_times(m,n,2);
            end
            
            rep_40 = find(win_oap(max_loc:end) <= 0.6,1);
            if ~isempty(rep_40)
                rep_times(m,n,4) = max_loc + rep_40;
            else
                rep_times(m,n,4) = rep_times(m,n,3);
            end
            
            rep_50 = find(win_oap(max_loc:end) <= 0.5,1);
            if ~isempty(rep_50)
                rep_times(m,n,5) = max_loc + rep_50;
            else
                rep_times(m,n,5) = rep_times(m,n,4);
            end
            
            rep_60 = find(win_oap(max_loc:end) <= 0.4,1);
            if ~isempty(rep_60)
                rep_times(m,n,6) = max_loc + rep_60;
            else
                rep_times(m,n,6) = rep_times(m,n,5);
            end
            
            rep_70 = find(win_oap(max_loc:end) <= 0.3,1);
            if ~isempty(rep_70)
                rep_times(m,n,7) = max_loc + rep_70;
            else
                rep_times(m,n,7) = rep_times(m,n,6);
            end
            
            rep_80 = find(win_oap(max_loc:end) <= 0.2,1);
            if ~isempty(rep_80)
                rep_times(m,n,8) = max_loc + rep_80;
            else
                rep_times(m,n,8) = rep_times(m,n,7);
            end
            
            rep_90 = find(win_oap(max_loc:end) <= 0.1,1);
            if ~isempty(rep_90)
                rep_times(m,n,9) = max_loc + rep_90;
            else
                rep_times(m,n,9) = rep_times(m,n,8);
            end
            
        end
    end
end

end



