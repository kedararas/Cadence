function rise_times = calculate_rise_times(cmos_data, start_frame, end_frame, act_times)

if isempty(act_times)
    act_times = calculate_activation_times(cmos_data, start_frame, end_frame);
end

win_data = cmos_data(:,:,start_frame:end_frame);
norm_win_data = normalize_data(win_data);

[num_rows, num_cols] = size(act_times);
rise_times = nan(num_rows, num_cols);

for i=1:num_rows
    for j=1:num_cols
        if ~isnan(norm_win_data(i,j,1)) && ~isnan(act_times(i,j))
            act_oap = squeeze(norm_win_data(i,j,:));
            act_time = act_times(i,j);
            
            rise_90 = find(act_oap(act_time:end) >= 0.9,1);
            rise_10 = find(act_oap(act_time:-1:1) <= 0.1,1);
            rise_duration = rise_90 + rise_10;
            
            if ~isempty(rise_duration) && rise_duration < 100 %physiological range
                rise_times(i,j) = rise_duration;
            end
        end
        
    end
end

end

