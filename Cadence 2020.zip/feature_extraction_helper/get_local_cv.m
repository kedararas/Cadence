function local_cv_map = get_local_cv(act_data)

 %% Find Conduction Velocity Map - Efimov Method
    % Fit Activation Map with New Surface based on Kernel Smoothing
    cind = isfinite(act_data);
    [x,y]= meshgrid(1:size(act_data,2),1:size(act_data,1));
    x = reshape(x,[],1);
    y = reshape(y,[],1);
    k_size = 3;
    h = fspecial('average',[k_size k_size]);
    Z_fit = filter2(h,act_data);
    % Remove Edge Effect Introduced from Kernel
    seD = strel('diamond',k_size-2);
    mask = imerode(cind,seD);
    mask(1,:) = 0;
    mask(end,:) = 0;
    mask(:,1) = 0;
    mask(:,end) = 0;
    Z = Z_fit.*mask;
    Z(Z==0) = nan;
    % Find Gradient of Polynomial Surface
    [Tx,Ty] = gradient(Z);
    % Calculate Conduction Velocity
    Vx = Tx./(Tx.^2+Ty.^2);
    Vy = -Ty./(Tx.^2+Ty.^2);
    
    Y_plot = 101 - y(isfinite(Z));
    X_plot = x(isfinite(Z));
    Vx_plot = Vx(isfinite(Z));
    Vx_plot(abs(Vx_plot) > 5) = 5.*sign(Vx_plot(abs(Vx_plot) > 5));
    Vy_plot = Vy(isfinite(Z));
    Vy_plot(abs(Vy_plot) > 5) = 5.*sign(Vy_plot(abs(Vy_plot) > 5));
    
    local_cv_map.x_plot = X_plot;
    local_cv_map.y_plot = Y_plot;
    local_cv_map.vx_plot = Vx_plot;
    local_cv_map.vy_plot = Vy_plot;
    
%     figure('Name','Local Conduction Velocity');
%     quiver(X_plot,Y_plot,Vx_plot,Vy_plot,3,'r');
%     close;


end

