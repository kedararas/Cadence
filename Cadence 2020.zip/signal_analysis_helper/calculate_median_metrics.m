function updated_data = calculate_median_metrics(data)
updated_data = data;
act_times = data.act_times;
rep_times = get_specific_feature_data(data.rep_times,8);
apd_times = get_specific_feature_data(data.apd_times,8);

updated_data.med_act_times = act_times{1,1};
updated_data.med_rep_times = rep_times{1,1};
updated_data.med_apd = apd_times{1,1};

num_signals = size(data.act_times,1);
if num_signals > 1
    [num_rows, num_cols] = size(act_times{1,1});
    act_data = zeros(num_rows, num_cols, num_signals);
    rep_data = zeros(num_rows, num_cols, num_signals);
    apd_data = zeros(num_rows, num_cols, num_signals);
    for i=1:num_signals
        act_data(:,:,i) = act_times{i,1} - nanmin(act_times{i,1}, [], 'all');
        rep_data(:,:,i) = rep_times{i,1} - nanmin(rep_times{i,1}, [], 'all');
        apd_data(:,:,i) = apd_times{i,1};
    end
    updated_data.med_act_times = fliplr(rot90(nanmedian(abs(act_data), 3),3));
    updated_data.med_rep_times = fliplr(rot90(nanmedian(abs(rep_data), 3),3));
    updated_data.med_apd = fliplr(rot90(nanmedian(abs(apd_data), 3),3));
    
end

end

