function hist_data = get_hist_data(label, data)
hist_data = [];
if ~isempty(data) && ~isempty(label)
    num_rows = size(data,1);
    for i=1:num_rows
        if strcmp(label, data{i,1})
            hist_data = data{i,2};
            break;
        end
    end
end

