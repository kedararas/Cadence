function extracted_data = get_specific_feature_data(data,index)
extracted_data = data;

if ~isempty(data) && index > 0
    num_rows = size(data,1);
    extracted_data = cell(num_rows,1);
    for i=1:num_rows
        row_data = data{i,1};
        col_data = squeeze(row_data(:,:,index));
        extracted_data{i,1} = col_data;
    end
end

