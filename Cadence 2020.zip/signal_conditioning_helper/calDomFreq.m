function [DF,RI,OI] = calDomFreq(cmos_data,Fs)
%% Window Data with Tukey Window to Minimize Edge Effects
if isempty(Fs)
    Fs = 1000;
end

num_frames = Fs/0.25;
if num_frames > size(cmos_data,3)
    num_frames = size(cmos_data,3);
end
cmos_data = cmos_data(:,:,1:num_frames);
num_rows = size(cmos_data,1);
num_cols = size(cmos_data,2);

w_m = tukeywin(size(cmos_data,3),.05);
win = repmat(permute(w_m,[3 2 1]),[size(cmos_data,1),size(cmos_data,2)]);
data = cmos_data.*win;
%% Find single-sided power spectrum of data
m = size(data,3);               % Window length
n = pow2(nextpow2(m));          % Transform Length
y = fft(data,n,3);              % DFT of signal
f = Fs/2*linspace(0,1,n/2+1);   % Frequency range
p = y.*conj(y)/n;               % Power of the DFT
p_s = 2*abs(p(:,:,1:n/2+1));    % Single-sided power
f(1) = [];                      % Remove DC
p_s(:,:,1) = [];                % Remove DC component
%% Find Dominant Frequency
[val,ind] = max(p_s,[],3);
DF = f(ind).*isfinite(val);
%tot_power = bandpower(reshape(cmos_data,[],num_rows*num_cols), Fs, [0,100]);

% msg = strcat('Dominant Frequency is: ', num2str(nanmedian(nanmedian(DF))));
% disp(msg);
RI = nan(num_rows,num_cols);
OI = nan(num_rows, num_cols);
for j=1:num_cols
    for i=1:num_rows
            oap = squeeze(cmos_data(i,j,:));
            total_power = bandpower(oap,Fs,[0,100]);
            df = DF(i,j);
            low = df - 0.75;
            if low < 0
                low = 0;
            end
            low_2 = df*2 - 0.75;
            if low_2 < 0
                low_2 = 0;
            end
            low_3 = df*3 - 0.75;
            if low_3 < 0
                low_3 = 0;
            end
            
            high = df + 0.75;
            high_2 = df*2 + 0.75;
            high_3 = df*3 + 0.75;
            
            df_power = bandpower(oap,Fs,[low,high]);
            df_power_2 = bandpower(oap,Fs,[low_2,high_2]);
            df_power_3 = bandpower(oap,Fs,[low_3,high_3]);
            
            RI(i,j) = df_power/total_power;
            OI(i,j) = (df_power + df_power_2 + df_power_3)/total_power;     
    end
end




% figure; imagesc(maxf); colormap(cmap);colorbar
% caxis([mean2(maxf)*.1 mean2(maxf)*2])