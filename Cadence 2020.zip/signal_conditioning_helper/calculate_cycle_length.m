function CL = calculate_cycle_length(cmos_all_data)
CL = nan(100,100);
DF = cmos_all_data.df_map;
%arrhytmia DF frequency is at least 4 Hz 
DF(DF < 4) = nan;
DF(DF > 30) = nan;
peak_DF = nanmedian(nanmedian(DF));
filt_data = cmos_all_data.filt_data;
frequency = cmos_all_data.frequency;
%frequency = 1000;
mask = cmos_all_data.mask;
min_peak_distance = round((750/peak_DF)*(frequency/1000));
%min_peak_distance = 50;

for i=1:100
    for j=1:100
        if ~isnan(mask(i,j))
            oap = squeeze(filt_data(i,j,:));
            [pks,locs] = findpeaks(oap, 'MinPeakDistance', min_peak_distance);
%             figure;
%             x_axis = 1:size(oap,1);
%             plot(x_axis, oap, locs, pks, 'or');
%             axis tight;
            diff_locs = diff(locs);
            interval = median(diff_locs);
            CL(i,j) = interval * 1000/frequency;
        end
    end
end

msg = strcat('Average Cycle Length (ms) is: ', num2str(nanmedian(nanmedian(CL))));
disp(msg);


end

