%GUI Helper to mask data using the dominant frequency
%INPUT: cmos_data, sampling frequency, and background image
%OUTPUT: masked cmos data, peak dominant frequency
function [masked_data,df_peak] = df_mask_data(cmos_data,sampling_frequency, bgimage)

[DF, df_peak] = extract_peak_df(cmos_data,sampling_frequency, bgimage);
DF_mask = ones(100,100);
DF_mask(DF ~= df_peak) = nan;
mask = repmat(DF_mask, [1 1 size(cmos_data,3)]);
masked_data = cmos_data .* mask;

end

