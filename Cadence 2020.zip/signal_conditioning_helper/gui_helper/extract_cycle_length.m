%GUI Helper to calculate cycle length in ms
%INPUT: cmos_data, dominant frequency
%OUTPUT: cycle length window
function [cycle_length_window] = extract_cycle_length(cmos_data,df_peak)

cycle_length = 1/(round(df_peak*10)/10);
cycle_length_window = cycle_length * 3;
if round (1000 *cycle_length_window) > size(cmos_data,3)
    cycle_length_window = cycle_length * 2;
end

end

