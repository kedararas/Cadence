%GUI Helper to calculate peak dominant frequency
%INPUT: cmos_data, sampling frequency, bgimage
%OUTPUT: masked cmos data, peak dominant frequency
function [DF, df_peak] = extract_peak_df(cmos_data,sampling_frequency, bgimage)

[DF,~] = calDomFreq(cmos_data, sampling_frequency);
image_mask = extract_image_mask(bgimage, 100);
temp = DF .* image_mask;
df_peak = mode(reshape(temp,[],1));

end

