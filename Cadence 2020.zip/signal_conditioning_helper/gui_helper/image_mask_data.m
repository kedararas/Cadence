%GUI Helper to mask data using the pixel intensity
%INPUT: cmos_data, and background image
%OUTPUT: masked cmos data
function [masked_data] = image_mask_data(cmos_data, bgimage)

image_mask = extract_image_mask(bgimage, 100);
mask = repmat(image_mask, [1 1 size(cmos_data,3)]);
masked_data = cmos_data .* mask;

end

