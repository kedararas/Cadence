function compare_wavefronts_video(epi, endo, start_frame, end_frame, video_file)

% Plot results
video_file = strcat(video_file, '.mp4');
writerObj = VideoWriter(video_file, 'MPEG-4');
writerObj.FrameRate = 10; % change this value to modify speed of movie
open(writerObj);

for i = start_frame:end_frame
    
    fig = figure;
    movegui(fig,'center');
    
    axis fill
    axis off;
    hold on
    
    epi_wf_list = epi.wavefronts{1,i};
    if ~isempty(epi_wf_list)
        num_orig_wf = size(epi_wf_list,2);
        for wf_count=1:num_orig_wf
            segWave = epi_wf_list{1,wf_count};
            if ~isempty(segWave)
                plot(segWave(1,:),segWave(2,:), 'Color', rgb('Red'), 'LineWidth', 3);
            end
        end
    end
    
    endo_wf_list = endo.wavefronts{1,i};
    if ~isempty(endo_wf_list)
        num_orig_wf = size(endo_wf_list,2);
        for wf_count=1:num_orig_wf
            segWave = endo_wf_list{1,wf_count};
            if ~isempty(segWave)
                plot(100-segWave(1,:),segWave(2,:), 'Color', rgb('Blue'), 'LineWidth', 3);
            end
        end
    end
    
    ps_disp_list = epi.ps{1,i};
    if ~isempty(ps_disp_list)
        num_ps = size(ps_disp_list,1);
        for ps_count = 1:num_ps
            x = ps_disp_list(ps_count,1);
            y = ps_disp_list(ps_count,2);
            plot(x,y, 'o', 'MarkerSize', 8, 'LineWidth', 4, 'MarkerEdgeColor', rgb('Black'), 'MarkerFaceColor',rgb('Red'));
        end
    end
    
    ps_disp_list = endo.ps{1,i};
    if ~isempty(ps_disp_list)
        num_ps = size(ps_disp_list,1);
        for ps_count = 1:num_ps
            x = 100-ps_disp_list(ps_count,1);
            y = ps_disp_list(ps_count,2);
            plot(x,y, 'o', 'MarkerSize', 8, 'LineWidth', 4, 'MarkerEdgeColor', rgb('Gray'), 'MarkerFaceColor',rgb('Blue'));
        end
    end
    
    pause(.0001)
    hold off
    frame = getframe(gcf);
    writeVideo(writerObj,frame);
    close(fig);
    
end

close(writerObj);
close all;





