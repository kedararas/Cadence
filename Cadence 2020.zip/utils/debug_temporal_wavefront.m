function debug_temporal_wavefront(first_list, second_list)

if ~isempty(first_list)
    num_first_wf = size(first_list,1);
end

if ~isempty(second_list)
    num_second_wf = size(second_list,1);
end

if num_first_wf > num_second_wf
    num_wf = num_first_wf;
else
    num_wf = num_second_wf;
end


for i=1:num_wf
    figure;
    hold on;
    axis fill
    xlim([0 100]);
    ylim([0 100]);
    axis off;
    
    if i <= num_first_wf
        first_wf = first_list{i,1};
    end
    if ~isempty(first_wf)
        plot(first_wf(:,1),first_wf(:,2), 'Color', rgb('Blue'), 'LineWidth', 3);
    end
    
    if i <= num_second_wf
        second_wf = second_list{i,1};
    end
    if ~isempty(second_wf)
        plot(second_wf(:,1),second_wf(:,2), 'Color', rgb('Red'), 'LineWidth', 3);
    end
end



