function debug_wavefront(first_list, second_list, wf, wf_cand_list)

f1 = figure;
hold on;
axis fill
axis off;

if ~isempty(first_list)
    num_orig_wf = size(first_list,1);
    for wf_count=1:num_orig_wf
        segWave = first_list{wf_count,1}.location;
        if ~isempty(segWave)
            plot(segWave(:,1),segWave(:,2), 'Color', rgb('Black'), 'LineWidth', 3);
        end
    end
    if ~isempty(wf)
        plot(wf.location(:,1),wf.location(:,2), 'Color', rgb('Blue'), 'LineWidth', 3);
    end
end

% f2 = figure;
% hold on;
% axis fill
% axis off;
% if ~isempty(second_list)
%     num_orig_wf = size(second_list,1);
%     for wf_count=1:num_orig_wf
%         segWave = second_list{wf_count,1}.location;
%         if ~isempty(segWave)
%             plot(segWave(:,1),segWave(:,2), 'Color', rgb('Black'), 'LineWidth', 3);
%         end
%     end
%     if ~isempty(wf_cand_list)
%         for x=1:size(wf_cand_list,1)
%             plot(second_list{wf_cand_list(x,2),1}.location(:,1),second_list{wf_cand_list(x,2),1}.location(:,2),'Color', rgb('Red'), 'LineWidth', 3);
%                 
%         end
%     end
% end


f3 = figure;
hold on;
axis fill
axis off;
if ~isempty(second_list)
    num_orig_wf = size(second_list,1);
    for wf_count=1:num_orig_wf
        segWave = second_list{wf_count,1}.location;
        if ~isempty(segWave)
            plot(segWave(:,1),segWave(:,2), 'Color', rgb('Black'), 'LineWidth', 3);
        end
    end
    if ~isempty(wf)
        plot(wf.location(:,1),wf.location(:,2), 'Color', rgb('Blue'), 'LineWidth', 3);
    end
    if ~isempty(wf_cand_list)
        for x=1:size(wf_cand_list,1)
            plot(second_list{wf_cand_list(x,2),1}.location(:,1),second_list{wf_cand_list(x,2),1}.location(:,2),'Color', rgb('Red'), 'LineWidth', 3);
                
        end
    end
end




end

