function generate_phase_video(data, start_frame, end_frame, video_file)

% Plot results
video_file = strcat(video_file, '.mp4');
writerObj = VideoWriter(video_file, 'MPEG-4');
writerObj.FrameRate = 2; % change this value to modify speed of movie
open(writerObj);

for i = start_frame:end_frame
    
    fig = figure;
    movegui(fig,'center');
    set(gcf, 'color', [1 1 1]);
    
    %bgimage = data.bgimage;
    bgimage = fliplr(data.bgimage);
    image(bgimage);
    hold on;
    
    frame = data.phase_data(:,:,i);
    frame(frame == 0) = nan;
    frame = fliplr(frame);
    contourf(frame, 128,'LineStyle', 'none');
    %imagesc(frame, "AlphaData", ~isnan(frame));
    colormap jet;
    caxis([-pi pi]);
    axis fill
    axis off;
    hold on
    
    wf_orig_list = data.wavefronts{1,i};
    if ~isempty(wf_orig_list)
        num_orig_wf = size(wf_orig_list,2);
        for wf_count=1:num_orig_wf
            segWave = wf_orig_list{1,wf_count};
            if ~isempty(segWave)
                %plot(segWave(1,:),segWave(2,:), 'Color', rgb('Ivory'), 'LineWidth', 3);
                plot(100-segWave(1,:),segWave(2,:), 'Color', rgb('Ivory'), 'LineWidth', 3);
            end
        end
    end
    
    ps_disp_list = data.ps{1,i};
    if ~isempty(ps_disp_list)
        num_ps = size(ps_disp_list,1);
        for ps_count = 1:num_ps
            x = ps_disp_list(ps_count,1);
            y = ps_disp_list(ps_count,2);
            charge = ps_disp_list(ps_count,3);
            if charge == 1
                %plot(x,y, 'o', 'MarkerSize', 8, 'LineWidth', 4, 'MarkerEdgeColor', rgb('Black'), 'MarkerFaceColor',rgb('Ivory'));
                plot(100-x,y, 'o', 'MarkerSize', 8, 'LineWidth', 4, 'MarkerEdgeColor', rgb('Black'), 'MarkerFaceColor',rgb('Ivory'));
            else
                %plot(x,y, 'o', 'MarkerSize', 8, 'LineWidth', 4, 'MarkerEdgeColor', rgb('Gray'), 'MarkerFaceColor',rgb('Ivory'));
                plot(100-x,y, 'o', 'MarkerSize', 8, 'LineWidth', 4, 'MarkerEdgeColor', rgb('Gray'), 'MarkerFaceColor',rgb('Ivory'));
            end
        end
    end
    
    pause(.0001)
    hold off
    frame = getframe(gcf);
    writeVideo(writerObj,frame);
    close(fig);
    
end

close(writerObj);
close all;





